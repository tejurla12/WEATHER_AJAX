const weatherData = require('./weatherData.json');

const branchProfiles = {
  "Hyderabad": { code: "NX-HYD-01", type: "Global Technology Center", lead: "Dr. Vikram Sethi", staff: 1420, tier: "Tier 1 Hub", budget: "₹18.4M" },
  "Chennai": { code: "NX-CHE-02", type: "Southern Logistics & QA", lead: "Ananya Sundaram", staff: 860, tier: "Tier 1 Hub", budget: "₹11.2M" },
  "Bengaluru": { code: "NX-BLR-03", type: "AI & Innovation Headquarters", lead: "Rajeshwar Rao", staff: 2150, tier: "Global HQ", budget: "₹34.5M" },
  "Mumbai": { code: "NX-MUM-04", type: "Financial Operations & Legal", lead: "Pooja Deshmukh", staff: 1680, tier: "Tier 1 Hub", budget: "₹26.0M" },
  "New Delhi": { code: "NX-DEL-05", type: "Corporate Strategy & Gov Relations", lead: "Harish Malhotra", staff: 1250, tier: "Tier 1 Hub", budget: "₹21.8M" },
  "Kolkata": { code: "NX-KOL-06", type: "Eastern Regional Services", lead: "Subhash Banerjee", staff: 740, tier: "Regional Hub", budget: "₹9.4M" },
  "Vijayawada": { code: "NX-VIJ-07", type: "Coastal Supply Operations", lead: "Srinivas Naidu", staff: 430, tier: "Regional Hub", budget: "₹5.8M" },
  "Visakhapatnam": { code: "NX-VIZ-08", type: "Maritime Logistics & Engineering", lead: "Kavita Reddy", staff: 510, tier: "Regional Hub", budget: "₹6.6M" },
  "Guntur": { code: "NX-GNT-09", type: "Agri-Tech & Data Node", lead: "Chaitanya Varma", staff: 320, tier: "Satellite Center", budget: "₹4.1M" },
  "Macherla": { code: "NX-MCH-10", type: "Renewable Systems Support", lead: "Raghavendra Rao", staff: 190, tier: "Satellite Center", budget: "₹2.6M" },
  "Pondicherry": { code: "NX-PON-11", type: "Creative Design & Experience Lab", lead: "Celine Bernard", staff: 280, tier: "Specialized Lab", budget: "₹3.9M" },
  "Coimbatore": { code: "NX-CBE-12", type: "Industrial Automation Tech", lead: "Murugan Swaminathan", staff: 620, tier: "Regional Hub", budget: "₹8.0M" },
  "Kochi": { code: "NX-KOC-13", type: "Maritime Systems & Cloud QA", lead: "Mohanlal Kurian", staff: 580, tier: "Regional Hub", budget: "₹7.4M" },
  "Thiruvananthapuram": { code: "NX-TVM-14", type: "Aerospace Data Engineering", lead: "Deepa Nambiar", staff: 490, tier: "Specialized Lab", budget: "₹6.5M" },
  "Pune": { code: "NX-PUN-15", type: "Automotive Software Core", lead: "Nikhil Joshi", staff: 1340, tier: "Tier 1 Hub", budget: "₹17.2M" },
  "Ahmedabad": { code: "NX-AHM-16", type: "Commercial Logistics & Trading", lead: "Gautam Patel", staff: 780, tier: "Regional Hub", budget: "₹10.1M" },
  "Jaipur": { code: "NX-JAI-17", type: "Customer Experience & CRM", lead: "Simran Shekhawat", staff: 650, tier: "Regional Hub", budget: "₹7.8M" },
  "Lucknow": { code: "NX-LKO-18", type: "Public Sector Solutions", lead: "Alok Srivastava", staff: 520, tier: "Regional Hub", budget: "₹6.2M" },
  "Bhopal": { code: "NX-BHP-19", type: "Central Infrastructure & Network", lead: "Manish Chouhan", staff: 410, tier: "Satellite Center", budget: "₹5.0M" },
  "Bhubaneswar": { code: "NX-BBI-20", type: "Bio-Informatics & Cloud Resiliency", lead: "Priyadarshi Mohanty", staff: 460, tier: "Regional Hub", budget: "₹5.9M" }
};

const initialBranches = weatherData.map((item, index) => {
  const profile = branchProfiles[item.city] || {
    code: `NX-${item.city.substring(0,3).toUpperCase()}-${index + 1}`,
    type: "Regional Office",
    lead: "Regional Director",
    staff: 350,
    tier: "Regional Hub",
    budget: "₹4.5M"
  };

  let operationalStatus = "Optimal";
  if (item.condition.toLowerCase().includes("rain")) {
    operationalStatus = "Weather Advisory";
  } else if (item.temperature >= 35) {
    operationalStatus = "Peak Thermal Load";
  }

  return {
    id: `br-${index + 1}`,
    code: profile.code,
    city: item.city,
    state: item.state,
    type: profile.type,
    tier: profile.tier,
    director: profile.lead,
    headcount: profile.staff,
    budget: profile.budget,
    status: operationalStatus,
    facilityHealth: Math.min(100, Math.max(90, 100 - Math.floor(item.windSpeed / 2))),
    environment: {
      temperature: item.temperature,
      condition: item.condition,
      humidity: item.humidity,
      windSpeed: item.windSpeed
    },
    lastAudit: "2026-11-10",
    activeIncidents: item.condition.toLowerCase().includes("rain") ? 1 : 0
  };
});

const initialEmployees = [
  { id: "EMP-1001", name: "Dr. Vikram Sethi", role: "VP of Enterprise Engineering", department: "Engineering", branch: "Hyderabad", email: "v.sethi@nexura.corp", phone: "+91 40 2309 4410", status: "Active", joined: "2021-03-15", performance: "Exceeds Expectations" },
  { id: "EMP-1002", name: "Ananya Sundaram", role: "Director of Quality Assurance", department: "Operations", branch: "Chennai", email: "a.sundaram@nexura.corp", phone: "+91 44 4892 1102", status: "Active", joined: "2022-01-10", performance: "Top Performer" },
  { id: "EMP-1003", name: "Rajeshwar Rao", role: "Chief Technology Officer", department: "Executive", branch: "Bengaluru", email: "r.rao@nexura.corp", phone: "+91 80 6100 9000", status: "Active", joined: "2019-06-01", performance: "Exceeds Expectations" },
  { id: "EMP-1004", name: "Pooja Deshmukh", role: "VP of Corporate Finance", department: "Finance", branch: "Mumbai", email: "p.deshmukh@nexura.corp", phone: "+91 22 6788 3344", status: "Active", joined: "2020-08-19", performance: "Exceeds Expectations" },
  { id: "EMP-1005", name: "Harish Malhotra", role: "Head of Government Relations", department: "Legal & Compliance", branch: "New Delhi", email: "h.malhotra@nexura.corp", phone: "+91 11 4110 5560", status: "Active", joined: "2021-11-04", performance: "Meets Expectations" },
  { id: "EMP-1006", name: "Subhash Banerjee", role: "Regional Operations Director", department: "Operations", branch: "Kolkata", email: "s.banerjee@nexura.corp", phone: "+91 33 2450 7890", status: "Active", joined: "2022-04-12", performance: "Exceeds Expectations" },
  { id: "EMP-1007", name: "Srinivas Naidu", role: "Supply Chain Manager", department: "Logistics", branch: "Vijayawada", email: "s.naidu@nexura.corp", phone: "+91 866 254 3321", status: "Active", joined: "2023-02-18", performance: "Meets Expectations" },
  { id: "EMP-1008", name: "Kavita Reddy", role: "Infrastructure Lead", department: "Engineering", branch: "Visakhapatnam", email: "k.reddy@nexura.corp", phone: "+91 891 662 1098", status: "On Leave", joined: "2022-07-25", performance: "Top Performer" },
  { id: "EMP-1009", name: "Nikhil Joshi", role: "Automotive Systems Architect", department: "Engineering", branch: "Pune", email: "n.joshi@nexura.corp", phone: "+91 20 6712 5500", status: "Active", joined: "2021-09-01", performance: "Top Performer" },
  { id: "EMP-1010", name: "Gautam Patel", role: "Director of Commercial Strategy", department: "Operations", branch: "Ahmedabad", email: "g.patel@nexura.corp", phone: "+91 79 4001 2233", status: "Active", joined: "2020-12-05", performance: "Exceeds Expectations" },
  { id: "EMP-1011", name: "Simran Shekhawat", role: "Head of Customer Experience", department: "Client Success", branch: "Jaipur", email: "s.shekhawat@nexura.corp", phone: "+91 141 289 4455", status: "Active", joined: "2023-05-14", performance: "Exceeds Expectations" },
  { id: "EMP-1012", name: "Celine Bernard", role: "Principal Experience Designer", department: "Product", branch: "Pondicherry", email: "c.bernard@nexura.corp", phone: "+91 413 223 9988", status: "Active", joined: "2022-09-20", performance: "Top Performer" },
  { id: "EMP-1013", name: "Mohanlal Kurian", role: "Senior Cloud Reliability Engineer", department: "Engineering", branch: "Kochi", email: "m.kurian@nexura.corp", phone: "+91 484 290 8877", status: "Active", joined: "2023-01-16", performance: "Meets Expectations" },
  { id: "EMP-1014", name: "Deepa Nambiar", role: "Lead Systems Researcher", department: "Engineering", branch: "Thiruvananthapuram", email: "d.nambiar@nexura.corp", phone: "+91 471 278 1234", status: "Active", joined: "2021-06-30", performance: "Exceeds Expectations" },
  { id: "EMP-1015", name: "Alok Srivastava", role: "Enterprise Solutions Manager", department: "Operations", branch: "Lucknow", email: "a.srivastava@nexura.corp", phone: "+91 522 405 6789", status: "Remote", joined: "2022-10-11", performance: "Meets Expectations" }
];

const initialDepartments = [
  { id: "DEP-1", name: "Engineering & Innovation", head: "Rajeshwar Rao", headcount: 6850, activeProjects: 42, budget: "₹65.2M", health: "98%" },
  { id: "DEP-2", name: "Operations & Facilities", head: "Ananya Sundaram", headcount: 3420, activeProjects: 28, budget: "₹38.6M", health: "95%" },
  { id: "DEP-3", name: "Finance & Corporate Audit", head: "Pooja Deshmukh", headcount: 1240, activeProjects: 14, budget: "₹24.0M", health: "99%" },
  { id: "DEP-4", name: "Logistics & Supply Chain", head: "Srinivas Naidu", headcount: 2180, activeProjects: 19, budget: "₹29.4M", health: "92%" },
  { id: "DEP-5", name: "Product & Experience", head: "Celine Bernard", headcount: 950, activeProjects: 16, budget: "₹18.8M", health: "97%" },
  { id: "DEP-6", name: "Legal & Regulatory Compliance", head: "Harish Malhotra", headcount: 480, activeProjects: 9, budget: "₹12.5M", health: "100%" }
];

const initialAnnouncements = [
  {
    id: "ANN-101",
    title: "Fiscal Q4 Regional Infrastructure & Sustainability Review",
    category: "Operations",
    date: "14 Nov 2026",
    priority: "High",
    author: "Executive Committee",
    summary: "All 20 regional facilities have completed the biannual HVAC, environmental resilience, and energy footprint audit. High-humidity mitigation systems in coastal hubs (Visakhapatnam, Kochi, Bhubaneswar) are operating at optimal parameters."
  },
  {
    id: "ANN-102",
    title: "Pan-India Hybrid Workplace Guidelines & Regional Shifts",
    category: "Human Resources",
    date: "12 Nov 2026",
    priority: "Normal",
    author: "People & Culture Operations",
    summary: "Flexible collaborative onsite rosters for Q4 are now published. Employee shuttle and transit connectivity across Tier 1 centers (Bengaluru, Hyderabad, Pune, Mumbai, Delhi) updated with new EV fleet deployment."
  },
  {
    id: "ANN-103",
    title: "Emergency Contingency Protocol: Coastal Rain & Monsoon Monitoring",
    category: "Safety & Facilities",
    date: "09 Nov 2026",
    priority: "High",
    author: "Enterprise Safety Board",
    summary: "Facilities teams in Mumbai, Kochi, and Bhubaneswar have activated Level 2 weather monitoring protocols. Secondary backup power generators and offline communications channels verified."
  }
];

const auditActivities = [
  { id: "ACT-1", action: "Branch Facility Audit Completed", target: "Bengaluru HQ (NX-BLR-03)", timestamp: "12 mins ago", user: "Facilities Ops" },
  { id: "ACT-2", action: "Weather Advisory Activated", target: "Visakhapatnam Hub (NX-VIZ-08)", timestamp: "45 mins ago", user: "Automated Telemetry" },
  { id: "ACT-3", action: "New Employee Onboarded", target: "Dr. Vikram Sethi assigned to Hyderabad", timestamp: "2 hours ago", user: "HR Central" },
  { id: "ACT-4", action: "Budget Reconciliation Finalized", target: "Finance Dept - Western Region", timestamp: "4 hours ago", user: "Audit System" },
  { id: "ACT-5", action: "HVAC Thermal Throttling Adjusted", target: "Ahmedabad Node (NX-AHM-16)", timestamp: "6 hours ago", user: "Smart Facility AI" }
];

module.exports = {
  initialBranches,
  initialEmployees,
  initialDepartments,
  initialAnnouncements,
  auditActivities
};
