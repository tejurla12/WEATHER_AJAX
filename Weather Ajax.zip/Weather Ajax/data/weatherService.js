const rawData = require('./weatherData.json');

// Generate realistic meteorological enrichment for each city
const enrichedWeatherData = rawData.map(item => {
  const isRain = item.condition.toLowerCase().includes('rain');
  const isCloud = item.condition.toLowerCase().includes('cloud');
  const isSunny = item.condition.toLowerCase().includes('sun');

  // Realistic Feels Like calculation
  const feelsLike = isSunny 
    ? item.temperature + Math.round(item.humidity * 0.08) 
    : isRain 
      ? item.temperature - 1 
      : item.temperature + 1;

  // UV Index
  const uvIndex = isSunny ? 8 : isCloud ? 4 : 2;
  const uvDescription = uvIndex >= 8 ? "Very High" : uvIndex >= 4 ? "Moderate" : "Low";

  // Visibility & Pressure
  const visibility = isRain ? 6.5 : isCloud ? 9.0 : 10.0;
  const pressure = isRain ? 1008 : 1014;

  // Air Quality Index (AQI)
  let aqi = 65;
  let aqiStatus = "Good";
  if (item.city === "New Delhi" || item.city === "Kolkata") {
    aqi = 148;
    aqiStatus = "Moderate";
  } else if (item.city === "Mumbai" || item.city === "Chennai") {
    aqi = 82;
    aqiStatus = "Satisfactory";
  } else if (item.city === "Bengaluru" || item.city === "Kochi") {
    aqi = 42;
    aqiStatus = "Clean";
  }

  // Hourly forecast for next 24 hours
  const hours = ['Now', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00', '00:00'];
  const hourly = hours.map((h, i) => {
    let tempOffset = 0;
    if (i === 0) tempOffset = 0;
    else if (i === 1) tempOffset = -3;
    else if (i === 2) tempOffset = 1;
    else if (i === 3) tempOffset = 3;
    else if (i === 4) tempOffset = 2;
    else if (i === 5) tempOffset = -1;
    else if (i === 6) tempOffset = -3;
    else tempOffset = -5;

    return {
      time: h,
      temp: item.temperature + tempOffset,
      condition: i > 4 && isSunny ? 'Partly Cloudy' : item.condition,
      pop: isRain ? Math.min(95, 60 + i * 4) : isCloud ? 25 : 5
    };
  });

  // 7-Day Extended Forecast
  const days = ['Today', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const daily = days.map((day, idx) => {
    const high = item.temperature + (idx % 2 === 0 ? 1 : -1);
    const low = Math.round(item.temperature * 0.72) + (idx % 3);
    let cond = item.condition;
    if (idx === 2 && isSunny) cond = 'Partly Cloudy';
    if (idx === 3 && isRain) cond = 'Cloudy';

    return {
      day,
      date: new Date(Date.now() + idx * 86400000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
      condition: cond,
      tempHigh: high,
      tempLow: low,
      humidity: Math.min(90, Math.max(30, item.humidity + (idx % 2 === 0 ? 3 : -4))),
      rainChance: isRain ? 80 : isCloud ? 30 : 10
    };
  });

  return {
    ...item,
    feelsLike,
    uvIndex,
    uvDescription,
    visibility,
    pressure,
    aqi,
    aqiStatus,
    dewPoint: Math.round(item.temperature - ((100 - item.humidity) / 5)),
    sunrise: "06:12 AM",
    sunset: "06:08 PM",
    windDirection: item.windSpeed > 14 ? "WSW" : "ENE",
    hourly,
    daily,
    alerts: isRain 
      ? [`Active Precipitation Advisory: Wet road conditions and gusty coastal winds up to ${item.windSpeed + 8} km/h.`]
      : item.temperature >= 35 
        ? [`High Thermal Notice: Peak midday temperatures of ${item.temperature}°C. Stay hydrated and avoid prolonged UV exposure.`]
        : []
  };
});

module.exports = {
  weatherList: enrichedWeatherData,
  getCityWeather: (cityName) => {
    return enrichedWeatherData.find(
      c => c.city.toLowerCase() === cityName.toLowerCase()
    );
  },
  getActiveAlerts: () => {
    return enrichedWeatherData
      .filter(c => c.alerts.length > 0)
      .map(c => ({
        city: c.city,
        state: c.state,
        condition: c.condition,
        temperature: c.temperature,
        alert: c.alerts[0]
      }));
  }
};
