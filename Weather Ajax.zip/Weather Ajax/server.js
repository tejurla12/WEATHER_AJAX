const express = require('express');
const cors = require('cors');
const path = require('path');
const { weatherList, getCityWeather, getActiveAlerts } = require('./data/weatherService');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// ================= API ENDPOINTS =================

// 1. All weather data with filtering
app.get('/api/weather', (req, res) => {
  const { search, state, condition } = req.query;
  let results = [...weatherList];

  if (search) {
    const q = search.toLowerCase();
    results = results.filter(item => 
      item.city.toLowerCase().includes(q) || 
      item.state.toLowerCase().includes(q)
    );
  }

  if (state && state !== 'All') {
    results = results.filter(item => item.state.toLowerCase() === state.toLowerCase());
  }

  if (condition && condition !== 'All') {
    results = results.filter(item => item.condition.toLowerCase().includes(condition.toLowerCase()));
  }

  res.json({
    count: results.length,
    data: results
  });
});

// 2. Specific city detailed forecast & observations
app.get('/api/weather/:city', (req, res) => {
  const city = getCityWeather(req.params.city);
  if (!city) {
    return res.status(404).json({ error: "Weather information not found for requested city." });
  }
  res.json(city);
});

// 3. National Summary & Extremes
app.get('/api/summary', (req, res) => {
  const sortedByTemp = [...weatherList].sort((a, b) => b.temperature - a.temperature);
  const sortedByHumidity = [...weatherList].sort((a, b) => b.humidity - a.humidity);
  const sortedByWind = [...weatherList].sort((a, b) => b.windSpeed - a.windSpeed);

  res.json({
    totalCities: weatherList.length,
    hottestCity: sortedByTemp[0],
    coolestCity: sortedByTemp[sortedByTemp.length - 1],
    highestHumidity: sortedByHumidity[0],
    windiestCity: sortedByWind[0],
    timestamp: new Date().toISOString()
  });
});

// 4. Active Weather & Precipitation Alerts
app.get('/api/alerts', (req, res) => {
  res.json({
    activeCount: getActiveAlerts().length,
    alerts: getActiveAlerts()
  });
});

// 5. Clean list of cities for search & dropdown
app.get('/api/cities', (req, res) => {
  const cities = weatherList.map(c => ({
    city: c.city,
    state: c.state,
    temperature: c.temperature,
    condition: c.condition
  }));
  res.json(cities);
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: "healthy", service: "Skypulse Weather Intelligence Core", port: PORT });
});

// Serve compiled React frontend
app.use(express.static(path.join(__dirname, 'dist')));

// SPA fallback for Express 5
app.use((req, res) => {
  const indexPath = path.join(__dirname, 'dist', 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      res.status(200).send(`
        <!DOCTYPE html>
        <html>
          <head><title>Skypulse Weather</title></head>
          <body style="font-family:sans-serif;padding:40px;text-align:center;">
            <h2>Skypulse Meteorological Server Running on Port ${PORT}</h2>
            <p>API is active at <code>/api/weather</code></p>
          </body>
        </html>
      `);
    }
  });
});

app.listen(PORT, () => {
  console.log(`[Skypulse Weather Engine] Online at http://localhost:${PORT}`);
});
