import React, { useState, useEffect } from 'react';
import WeatherHeader from './components/WeatherHeader';
import HeroWeatherCard from './components/HeroWeatherCard';
import MetricsOverview from './components/MetricsOverview';
import HourlyForecast from './components/HourlyForecast';
import DailyForecast from './components/DailyForecast';
import AllCitiesExplorer from './components/AllCitiesExplorer';
import AlertsBanner from './components/AlertsBanner';

export default function App() {
  const [allCities, setAllCities] = useState([]);
  const [currentCityName, setCurrentCityName] = useState('Hyderabad');
  const [currentCityData, setCurrentCityData] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [unit, setUnit] = useState('C');
  const [theme, setTheme] = useState('dark');
  const [loading, setLoading] = useState(true);

  // Quick Access Chips for Major Metros
  const quickChips = [
    'Hyderabad', 'Chennai', 'Bengaluru', 'Mumbai', 
    'New Delhi', 'Kolkata', 'Pune', 'Visakhapatnam', 'Kochi'
  ];

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    if (nextTheme === 'light') {
      document.body.classList.add('theme-light');
    } else {
      document.body.classList.remove('theme-light');
    }
  };

  // Fetch initial data
  useEffect(() => {
    const initData = async () => {
      try {
        setLoading(true);
        const [weatherRes, alertsRes] = await Promise.all([
          fetch('/api/weather'),
          fetch('/api/alerts')
        ]);

        if (weatherRes.ok) {
          const wJson = await weatherRes.json();
          setAllCities(wJson.data || []);
          if (wJson.data && wJson.data.length > 0) {
            fetchCityDetails('Hyderabad');
          }
        }

        if (alertsRes.ok) {
          const aJson = await alertsRes.json();
          setAlerts(aJson.alerts || []);
        }
      } catch (err) {
        console.error("Error fetching meteorological data:", err);
      } finally {
        setLoading(false);
      }
    };

    initData();
  }, []);

  // Fetch specific city details
  const fetchCityDetails = async (cityName) => {
    try {
      const res = await fetch(`/api/weather/${encodeURIComponent(cityName)}`);
      if (res.ok) {
        const data = await res.json();
        setCurrentCityData(data);
        setCurrentCityName(data.city);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    } catch (err) {
      console.error(`Error fetching weather for ${cityName}:`, err);
    }
  };

  return (
    <div>
      <WeatherHeader 
        unit={unit} 
        setUnit={setUnit} 
        theme={theme} 
        toggleTheme={toggleTheme} 
      />

      <main className="page-container">
        {/* Active Weather Advisories Banner */}
        <AlertsBanner 
          alerts={alerts} 
          onSelectCity={fetchCityDetails} 
        />

        {/* Quick City Navigation Chips */}
        <div className="quick-cities-bar">
          <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginRight: '4px' }}>
            Quick Hubs:
          </span>
          {quickChips.map(cityName => (
            <button
              key={cityName}
              className={`quick-city-chip ${currentCityName.toLowerCase() === cityName.toLowerCase() ? 'active' : ''}`}
              onClick={() => fetchCityDetails(cityName)}
            >
              {cityName}
            </button>
          ))}
        </div>

        {/* Hero Card with Dropdown & Search & Current Weather Details */}
        {currentCityData && (
          <HeroWeatherCard 
            currentCity={currentCityData}
            allCities={allCities}
            onSelectCity={fetchCityDetails}
            unit={unit}
          />
        )}

        {/* 6 Key Atmospheric Gauges */}
        {currentCityData && (
          <MetricsOverview 
            currentCity={currentCityData}
            unit={unit}
          />
        )}

        {/* 2-Column Split: 24-Hour Timeline and 7-Day Forecast */}
        {currentCityData && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
            <HourlyForecast 
              hourly={currentCityData.hourly}
              unit={unit}
            />

            <DailyForecast 
              daily={currentCityData.daily}
              unit={unit}
            />
          </div>
        )}

        {/* Comprehensive National 20-City Registry & Filter */}
        <AllCitiesExplorer 
          allCities={allCities}
          currentCityName={currentCityName}
          onSelectCity={fetchCityDetails}
          unit={unit}
        />
      </main>
    </div>
  );
}
