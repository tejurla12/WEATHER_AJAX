import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Sun, 
  Moon, 
  RotateCw, 
  Plus, 
  Search,
  CheckCircle2,
  SlidersHorizontal
} from 'lucide-react';

export default function Navbar({ activeTab, onRefresh, onQuickAction, theme, toggleTheme }) {
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false 
      }) + ' IST');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const tabTitles = {
    overview: 'Executive Dashboard & Regional Overview',
    branches: 'Pan-India Regional Hubs & Facility Environmental Telemetry',
    workforce: 'Personnel & Enterprise Workforce Directory',
    departments: 'Organizational Divisions & Departmental Capital Allocation',
    announcements: 'Official Enterprise Notices & Policy Communications'
  };

  return (
    <header className="top-navbar">
      <div className="page-breadcrumb">
        <span>Corporate Portal</span>
        <span>/</span>
        <span className="current">{tabTitles[activeTab] || 'Overview'}</span>
      </div>

      <div className="top-actions">
        <div className="live-clock-badge">
          <span className="live-pulse"></span>
          <span>{currentTime}</span>
        </div>

        <button 
          className="btn-icon" 
          title="Toggle Dark/Light Mode"
          onClick={toggleTheme}
        >
          {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        <button 
          className="btn-icon" 
          title="Synchronize Regional Telemetry"
          onClick={onRefresh}
        >
          <RotateCw size={16} />
        </button>

        <button 
          className="btn-primary" 
          onClick={onQuickAction}
        >
          <Plus size={16} />
          <span>New Action</span>
        </button>
      </div>
    </header>
  );
}
