import React from 'react';
import { Clock, Droplets, ConditionIcon } from './WeatherIcons';

export default function HourlyForecast({ hourly, unit }) {
  if (!hourly || hourly.length === 0) return null;

  const formatTemp = (celsius) => {
    if (unit === 'F') {
      return Math.round((celsius * 9/5) + 32);
    }
    return Math.round(celsius);
  };

  return (
    <div className="glass-card" style={{ padding: '24px', marginBottom: '28px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px', fontWeight: 700, color: 'var(--text-main)' }}>
          <Clock size={17} color="#0284c7" />
          <span>24-Hour Atmospheric Timeline</span>
        </div>
        <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Scroll horizontally</span>
      </div>

      <div className="hourly-scroller">
        {hourly.map((item, index) => (
          <div 
            key={index} 
            className={`hourly-card ${index === 0 ? 'active-hour' : ''}`}
          >
            <span style={{ fontSize: '12px', fontWeight: 600, color: index === 0 ? '#0284c7' : 'var(--text-muted)' }}>
              {item.time}
            </span>

            <ConditionIcon condition={item.condition} size={28} />

            <span style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-main)' }}>
              {formatTemp(item.temp)}°{unit}
            </span>

            <div style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: item.pop > 40 ? '#38bdf8' : 'var(--text-dim)' }}>
              <Droplets size={11} />
              <span>{item.pop}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
