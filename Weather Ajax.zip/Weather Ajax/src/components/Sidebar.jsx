import React from 'react';
import { 
  LayoutDashboard, 
  Building2, 
  Users, 
  Layers, 
  Megaphone, 
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, branchCount, employeeCount }) {
  const menuItems = [
    { id: 'overview', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'branches', label: 'Regional Hubs & Facilities', icon: Building2, badge: branchCount },
    { id: 'workforce', label: 'Workforce Directory', icon: Users, badge: employeeCount },
    { id: 'departments', label: 'Enterprise Divisions', icon: Layers },
    { id: 'announcements', label: 'Corporate Bulletins', icon: Megaphone }
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="brand-badge">NX</div>
        <div className="brand-title">
          <span>NEXURA</span>
          <span className="brand-sub">Enterprise Portal</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <div
              key={item.id}
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <Icon size={19} />
              <span className="nav-text">{item.label}</span>
              {item.badge !== undefined && (
                <span className="nav-badge">{item.badge}</span>
              )}
            </div>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="user-profile-widget">
          <div className="user-avatar">SR</div>
          <div className="user-info">
            <span className="user-name">S. Raghavan</span>
            <span className="user-role">Managing Director</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
