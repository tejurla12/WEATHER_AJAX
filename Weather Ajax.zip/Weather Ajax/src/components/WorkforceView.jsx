import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  UserPlus, 
  Mail, 
  Phone, 
  Trash2, 
  MapPin, 
  Briefcase,
  CheckCircle,
  Clock
} from 'lucide-react';

export default function WorkforceView({ employees, branches, onAddEmployee, onDeleteEmployee }) {
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');
  const [branchFilter, setBranchFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New employee form state
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    department: 'Engineering',
    branch: branches[0]?.city || 'Bengaluru',
    email: '',
    phone: '',
    status: 'Active'
  });

  const departments = ['All', 'Engineering', 'Operations', 'Finance', 'Logistics', 'Product', 'Legal & Compliance', 'Client Success'];
  const branchList = ['All', ...Array.from(new Set(branches.map(b => b.city))).sort()];
  const statusList = ['All', 'Active', 'Remote', 'On Leave'];

  const filtered = employees.filter(emp => {
    const q = search.toLowerCase();
    const matchesSearch = 
      emp.name.toLowerCase().includes(q) ||
      emp.role.toLowerCase().includes(q) ||
      emp.id.toLowerCase().includes(q) ||
      emp.email.toLowerCase().includes(q);

    const matchesDept = deptFilter === 'All' || emp.department === deptFilter;
    const matchesBranch = branchFilter === 'All' || emp.branch === branchFilter;
    const matchesStatus = statusFilter === 'All' || emp.status === statusFilter;

    return matchesSearch && matchesDept && matchesBranch && matchesStatus;
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.role) return;
    onAddEmployee(formData);
    setIsAddModalOpen(false);
    setFormData({
      name: '',
      role: '',
      department: 'Engineering',
      branch: branches[0]?.city || 'Bengaluru',
      email: '',
      phone: '',
      status: 'Active'
    });
  };

  return (
    <div>
      {/* Top Header & Actions */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '24px' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-primary)' }}>
            Enterprise Workforce & Personnel Directory
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '3px' }}>
            Active roster of personnel, directors, and division managers across all facilities
          </p>
        </div>

        <button className="btn-primary" onClick={() => setIsAddModalOpen(true)}>
          <UserPlus size={16} />
          <span>Onboard Employee</span>
        </button>
      </div>

      {/* Filter Row */}
      <div className="card" style={{ padding: '16px 20px', marginBottom: '24px', display: 'flex', flexWrap: 'wrap', gap: '14px', alignItems: 'center' }}>
        {/* Search */}
        <div style={{ position: 'relative', flex: '1', minWidth: '240px' }}>
          <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            placeholder="Search by name, role, email, ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field"
            style={{ paddingLeft: '34px', fontSize: '13px' }}
          />
        </div>

        {/* Department Filter */}
        <div style={{ minWidth: '160px' }}>
          <select 
            className="select-field"
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            style={{ fontSize: '13px' }}
          >
            {departments.map(d => (
              <option key={d} value={d}>{d === 'All' ? 'All Departments' : d}</option>
            ))}
          </select>
        </div>

        {/* Branch Filter */}
        <div style={{ minWidth: '150px' }}>
          <select 
            className="select-field"
            value={branchFilter}
            onChange={(e) => setBranchFilter(e.target.value)}
            style={{ fontSize: '13px' }}
          >
            {branchList.map(b => (
              <option key={b} value={b}>{b === 'All' ? 'All Hubs' : b}</option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div style={{ minWidth: '130px' }}>
          <select 
            className="select-field"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ fontSize: '13px' }}
          >
            {statusList.map(s => (
              <option key={s} value={s}>{s === 'All' ? 'All Work Modes' : s}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Employees Table */}
      <div className="data-table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th>Employee Name & ID</th>
              <th>Designation / Role</th>
              <th>Department</th>
              <th>Assigned Hub</th>
              <th>Contact Details</th>
              <th>Status</th>
              <th>Performance</th>
              <th style={{ textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan="8" style={{ textAlign: 'center', padding: '36px', color: 'var(--text-muted)' }}>
                  No personnel matching the current filters.
                </td>
              </tr>
            ) : (
              filtered.map(emp => {
                const initials = emp.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                
                let statusBadge = 'status-optimal';
                if (emp.status === 'Remote') statusBadge = 'status-info';
                if (emp.status === 'On Leave') statusBadge = 'status-warning';

                return (
                  <tr key={emp.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div style={{
                          width: '34px',
                          height: '34px',
                          borderRadius: '8px',
                          background: 'linear-gradient(135deg, #3b82f6, #06b6d4)',
                          color: '#fff',
                          fontWeight: 700,
                          fontSize: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center'
                        }}>
                          {initials}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{emp.name}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)', fontFamily: 'monospace' }}>{emp.id}</div>
                        </div>
                      </div>
                    </td>

                    <td>
                      <div style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{emp.role}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Joined {emp.joined}</div>
                    </td>

                    <td>
                      <span style={{ 
                        padding: '3px 8px', 
                        borderRadius: '4px', 
                        background: 'var(--bg-surface-elevated)', 
                        fontSize: '12px', 
                        fontWeight: 500,
                        border: '1px solid var(--border-subtle)'
                      }}>
                        {emp.department}
                      </span>
                    </td>

                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '13px', fontWeight: 500 }}>
                        <MapPin size={13} color="#3b82f6" />
                        <span>{emp.branch}</span>
                      </div>
                    </td>

                    <td>
                      <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{emp.email}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{emp.phone}</div>
                    </td>

                    <td>
                      <span className={`status-badge ${statusBadge}`}>
                        {emp.status}
                      </span>
                    </td>

                    <td>
                      <span style={{ fontSize: '12px', fontWeight: 600, color: emp.performance === 'Top Performer' ? '#10b981' : 'var(--text-secondary)' }}>
                        {emp.performance}
                      </span>
                    </td>

                    <td style={{ textAlign: 'right' }}>
                      <button 
                        onClick={() => onDeleteEmployee(emp.id)}
                        className="btn-icon" 
                        style={{ width: '30px', height: '30px', display: 'inline-flex' }}
                        title="Offboard Employee"
                      >
                        <Trash2 size={13} color="#f43f5e" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Onboard Employee Modal */}
      {isAddModalOpen && (
        <div className="modal-overlay" onClick={() => setIsAddModalOpen(false)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Onboard Enterprise Personnel</h3>
              <button 
                onClick={() => setIsAddModalOpen(false)} 
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '18px' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                <div className="form-group">
                  <label>Full Name *</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. Radhika Sharma"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="input-field"
                  />
                </div>

                <div className="form-group">
                  <label>Designation / Role Title *</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. Senior Cloud Architect"
                    value={formData.role}
                    onChange={e => setFormData({ ...formData, role: e.target.value })}
                    className="input-field"
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div className="form-group">
                    <label>Department</label>
                    <select 
                      className="select-field"
                      value={formData.department}
                      onChange={e => setFormData({ ...formData, department: e.target.value })}
                    >
                      {departments.filter(d => d !== 'All').map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Assigned Regional Hub</label>
                    <select 
                      className="select-field"
                      value={formData.branch}
                      onChange={e => setFormData({ ...formData, branch: e.target.value })}
                    >
                      {branchList.filter(b => b !== 'All').map(b => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div className="form-group">
                    <label>Work Email</label>
                    <input 
                      type="email" 
                      placeholder="name@nexura.corp"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="input-field"
                    />
                  </div>

                  <div className="form-group">
                    <label>Work Phone</label>
                    <input 
                      type="tel" 
                      placeholder="+91 98400 ..."
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="input-field"
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>Work Arrangement</label>
                  <select 
                    className="select-field"
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value })}
                  >
                    <option value="Active">Active (Onsite Hub)</option>
                    <option value="Remote">Remote Approved</option>
                    <option value="On Leave">On Leave</option>
                  </select>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn-secondary" onClick={() => setIsAddModalOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Confirm Onboarding
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
