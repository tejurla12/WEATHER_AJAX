import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  Filter, 
  MapPin, 
  Thermometer, 
  Droplets, 
  Wind, 
  UserCheck, 
  Edit3, 
  ShieldAlert,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export default function BranchesView({ branches, onUpdateBranch }) {
  const [search, setSearch] = useState('');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [editingBranch, setEditingBranch] = useState(null);
  const [newStatus, setNewStatus] = useState('');
  const [newDirector, setNewDirector] = useState('');

  const states = ['All', ...Array.from(new Set(branches.map(b => b.state))).sort()];
  const statuses = ['All', 'Optimal', 'Weather Advisory', 'Peak Thermal Load'];

  const filtered = branches.filter(b => {
    const matchesSearch = 
      b.city.toLowerCase().includes(search.toLowerCase()) ||
      b.state.toLowerCase().includes(search.toLowerCase()) ||
      b.code.toLowerCase().includes(search.toLowerCase()) ||
      b.director.toLowerCase().includes(search.toLowerCase());

    const matchesState = selectedState === 'All' || b.state === selectedState;
    const matchesStatus = selectedStatus === 'All' || b.status === selectedStatus;

    return matchesSearch && matchesState && matchesStatus;
  });

  const handleEditClick = (branch) => {
    setEditingBranch(branch);
    setNewStatus(branch.status);
    setNewDirector(branch.director);
  };

  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!editingBranch) return;
    onUpdateBranch(editingBranch.id, {
      status: newStatus,
      director: newDirector
    });
    setEditingBranch(null);
  };

  return (
    <div>
      {/* Header & Controls */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '24px' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-primary)' }}>
            Regional Hubs & Facility Atmospheric Telemetry
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '3px' }}>
            Managing 20 corporate centers with live climate resilience monitoring across India
          </p>
        </div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ position: 'relative', minWidth: '220px' }}>
            <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input 
              type="text" 
              placeholder="Search by city, code, director..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-field"
              style={{ paddingLeft: '34px', fontSize: '13px' }}
            />
          </div>

          {/* State Filter */}
          <select 
            className="select-field"
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            style={{ width: 'auto', fontSize: '13px' }}
          >
            {states.map(st => (
              <option key={st} value={st}>{st === 'All' ? 'All States' : st}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select 
            className="select-field"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            style={{ width: 'auto', fontSize: '13px' }}
          >
            {statuses.map(st => (
              <option key={st} value={st}>{st === 'All' ? 'All Statuses' : st}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid of Regional Hubs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '20px' }}>
        {filtered.map(branch => {
          const isRain = branch.environment?.condition?.toLowerCase().includes('rain');
          const isHighTemp = branch.environment?.temperature >= 35;
          
          let badgeClass = 'status-optimal';
          if (branch.status === 'Weather Advisory') badgeClass = 'status-warning';
          if (branch.status === 'Peak Thermal Load') badgeClass = 'status-alert';

          return (
            <div key={branch.id} className="card" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              
              {/* Card Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '16px', fontWeight: 800, color: 'var(--text-primary)' }}>
                      {branch.city}
                    </span>
                    <span style={{ fontSize: '11px', fontFamily: 'monospace', padding: '2px 6px', background: 'var(--bg-surface-elevated)', borderRadius: '4px', color: 'var(--text-muted)' }}>
                      {branch.code}
                    </span>
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                    <MapPin size={12} />
                    <span>{branch.state}</span>
                    <span>•</span>
                    <span style={{ color: 'var(--primary)', fontWeight: 500 }}>{branch.tier}</span>
                  </div>
                </div>

                <span className={`status-badge ${badgeClass}`}>
                  {branch.status}
                </span>
              </div>

              {/* Branch Details */}
              <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '8px', padding: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Function: </span> 
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{branch.type}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Branch Lead:</span>
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{branch.director}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Active Workforce:</span>
                  <span style={{ fontWeight: 700, color: '#3b82f6' }}>{branch.headcount.toLocaleString()} staff</span>
                </div>
              </div>

              {/* Live Environmental & Atmospheric Telemetry */}
              <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '12px' }}>
                <div style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.04em', color: 'var(--text-muted)', fontWeight: 700, marginBottom: '8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>Environmental Telemetry</span>
                  <span style={{ color: 'var(--accent-emerald)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <CheckCircle2 size={11} /> Connected
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', textAlign: 'center' }}>
                  <div style={{ padding: '8px', background: 'var(--bg-surface-elevated)', borderRadius: '6px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', fontSize: '14px', fontWeight: 700 }}>
                      <Thermometer size={13} color={isHighTemp ? '#f43f5e' : '#3b82f6'} />
                      <span>{branch.environment?.temperature}°C</span>
                    </div>
                    <span style={{ fontSize: '10.5px', color: 'var(--text-muted)' }}>{branch.environment?.condition}</span>
                  </div>

                  <div style={{ padding: '8px', background: 'var(--bg-surface-elevated)', borderRadius: '6px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', fontSize: '14px', fontWeight: 700 }}>
                      <Droplets size={13} color="#06b6d4" />
                      <span>{branch.environment?.humidity}%</span>
                    </div>
                    <span style={{ fontSize: '10.5px', color: 'var(--text-muted)' }}>Humidity</span>
                  </div>

                  <div style={{ padding: '8px', background: 'var(--bg-surface-elevated)', borderRadius: '6px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', fontSize: '14px', fontWeight: 700 }}>
                      <Wind size={13} color="#8b5cf6" />
                      <span>{branch.environment?.windSpeed} km/h</span>
                    </div>
                    <span style={{ fontSize: '10.5px', color: 'var(--text-muted)' }}>Wind Speed</span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', borderTop: '1px solid var(--border-subtle)', paddingTop: '12px' }}>
                <span style={{ fontSize: '11.5px', color: 'var(--text-muted)' }}>
                  Facility Health: <strong style={{ color: 'var(--text-primary)' }}>{branch.facilityHealth}%</strong>
                </span>

                <button 
                  className="btn-secondary" 
                  style={{ fontSize: '11.5px', padding: '5px 10px', gap: '4px' }}
                  onClick={() => handleEditClick(branch)}
                >
                  <Edit3 size={12} />
                  <span>Configure</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Edit Branch Modal */}
      {editingBranch && (
        <div className="modal-overlay" onClick={() => setEditingBranch(null)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Configure Facility: {editingBranch.city} ({editingBranch.code})</h3>
              <button 
                onClick={() => setEditingBranch(null)} 
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '18px' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit}>
              <div className="modal-body">
                <div className="form-group">
                  <label>Facility Location & Code</label>
                  <input 
                    type="text" 
                    value={`${editingBranch.city}, ${editingBranch.state} - ${editingBranch.code}`} 
                    disabled 
                    className="input-field" 
                    style={{ opacity: 0.7 }}
                  />
                </div>

                <div className="form-group">
                  <label>Regional Branch Director / VP</label>
                  <input 
                    type="text" 
                    value={newDirector} 
                    onChange={e => setNewDirector(e.target.value)}
                    required 
                    className="input-field"
                  />
                </div>

                <div className="form-group">
                  <label>Operational Status</label>
                  <select 
                    className="select-field"
                    value={newStatus}
                    onChange={e => setNewStatus(e.target.value)}
                  >
                    <option value="Optimal">Optimal (Normal Capacity)</option>
                    <option value="Weather Advisory">Weather Advisory (Monsoon/Storm Mode)</option>
                    <option value="Peak Thermal Load">Peak Thermal Load (HVAC Conserve)</option>
                  </select>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn-secondary" onClick={() => setEditingBranch(null)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Save Configuration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
