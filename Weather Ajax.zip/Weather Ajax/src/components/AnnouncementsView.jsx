import React, { useState } from 'react';
import { Megaphone, Plus, Calendar, User, Tag, AlertCircle, CheckCircle } from 'lucide-react';

export default function AnnouncementsView({ announcements, onAddAnnouncement }) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState('All');
  const [formData, setFormData] = useState({
    title: '',
    category: 'Operations',
    priority: 'Normal',
    summary: ''
  });

  const categories = ['All', 'Operations', 'Human Resources', 'Safety & Facilities'];

  const filtered = filter === 'All' 
    ? announcements 
    : announcements.filter(a => a.category === filter);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title || !formData.summary) return;
    onAddAnnouncement(formData);
    setIsModalOpen(false);
    setFormData({
      title: '',
      category: 'Operations',
      priority: 'Normal',
      summary: ''
    });
  };

  return (
    <div>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '24px' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-primary)' }}>
            Corporate Bulletins & Executive Directives
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '3px' }}>
            Official organization-wide notices, climate advisories, and facility protocols
          </p>
        </div>

        <button className="btn-primary" onClick={() => setIsModalOpen(true)}>
          <Plus size={16} />
          <span>Publish Bulletin</span>
        </button>
      </div>

      {/* Category Filter Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', overflowX: 'auto', paddingBottom: '4px' }}>
        {categories.map(cat => (
          <button
            key={cat}
            className={`btn-secondary ${filter === cat ? 'active' : ''}`}
            onClick={() => setFilter(cat)}
            style={{
              background: filter === cat ? 'var(--primary-light)' : 'var(--bg-surface)',
              color: filter === cat ? 'var(--primary)' : 'var(--text-secondary)',
              borderColor: filter === cat ? 'var(--primary)' : 'var(--border-subtle)',
              fontWeight: filter === cat ? 600 : 500
            }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Bulletins List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {filtered.map(item => (
          <div key={item.id} className="card" style={{ padding: '22px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
                  <span className={`status-badge ${item.priority === 'High' ? 'status-alert' : 'status-info'}`}>
                    {item.priority} Priority
                  </span>
                  <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--primary)' }}>
                    {item.category}
                  </span>
                </div>
                <h3 style={{ fontSize: '17px', fontWeight: 700, color: 'var(--text-primary)' }}>
                  {item.title}
                </h3>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', fontSize: '12px', color: 'var(--text-muted)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <Calendar size={13} /> {item.date}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <User size={13} /> {item.author}
                </span>
              </div>
            </div>

            <p style={{ fontSize: '13.5px', color: 'var(--text-secondary)', lineHeight: '1.6', marginTop: '12px' }}>
              {item.summary}
            </p>
          </div>
        ))}
      </div>

      {/* Publish Bulletin Modal */}
      {isModalOpen && (
        <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Publish Official Directive</h3>
              <button 
                onClick={() => setIsModalOpen(false)} 
                style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '18px' }}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="modal-body">
                <div className="form-group">
                  <label>Bulletin Title *</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. Q4 Regional Operations & Energy Protocol"
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    className="input-field"
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div className="form-group">
                    <label>Category</label>
                    <select 
                      className="select-field"
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                    >
                      <option value="Operations">Operations</option>
                      <option value="Human Resources">Human Resources</option>
                      <option value="Safety & Facilities">Safety & Facilities</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Broadcast Priority</label>
                    <select 
                      className="select-field"
                      value={formData.priority}
                      onChange={e => setFormData({ ...formData, priority: e.target.value })}
                    >
                      <option value="Normal">Normal Priority</option>
                      <option value="High">High (Immediate Action)</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label>Full Directive Summary *</label>
                  <textarea 
                    rows="4" 
                    required 
                    placeholder="Enter the official communication details for all regional facilities..."
                    value={formData.summary}
                    onChange={e => setFormData({ ...formData, summary: e.target.value })}
                    className="textarea-field"
                  ></textarea>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn-secondary" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn-primary">
                  Broadcast Bulletin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
