import React from 'react';
import { 
  Droplets, 
  Wind, 
  SunMedium, 
  Activity, 
  Eye, 
  Gauge,
  Compass
} from './WeatherIcons';

export default function MetricsOverview({ currentCity, unit }) {
  if (!currentCity) return null;

  // Humidity status
  let humidityComfort = "Comfortable";
  if (currentCity.humidity > 70) humidityComfort = "High / Humid";
  else if (currentCity.humidity < 40) humidityComfort = "Dry Air";

  // Wind speed display
  const windDisplay = unit === 'F' 
    ? `${Math.round(currentCity.windSpeed * 0.621371)} mph`
    : `${currentCity.windSpeed} km/h`;

  let windScale = "Gentle Breeze";
  if (currentCity.windSpeed > 15) windScale = "Moderate Breeze";
  if (currentCity.windSpeed > 25) windScale = "Strong Gale";

  return (
    <div className="metrics-grid">
      
      {/* Humidity */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>Humidity</span>
          <Droplets size={16} color="#38bdf8" />
        </div>
        <div className="metric-value">
          {currentCity.humidity}%
        </div>
        <div className="metric-sub">
          The dew point is {currentCity.dewPoint}° right now. ({humidityComfort})
        </div>
      </div>

      {/* Wind Speed */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>Wind Speed & Vector</span>
          <Wind size={16} color="#818cf8" />
        </div>
        <div className="metric-value">
          {windDisplay}
        </div>
        <div className="metric-sub">
          {currentCity.windDirection} • {windScale}
        </div>
      </div>

      {/* UV Index */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>UV Index</span>
          <SunMedium size={16} color="#fbbf24" />
        </div>
        <div className="metric-value">
          {currentCity.uvIndex} <span style={{ fontSize: '15px', color: 'var(--text-muted)' }}>/ 10</span>
        </div>
        <div className="metric-sub">
          {currentCity.uvDescription} UV exposure during midday hours.
        </div>
      </div>

      {/* Air Quality Index (AQI) */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>Air Quality Index</span>
          <Activity size={16} color="#10b981" />
        </div>
        <div className="metric-value" style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
          <span>{currentCity.aqi}</span>
          <span style={{ fontSize: '13px', fontWeight: 600, color: currentCity.aqi < 100 ? '#10b981' : '#f59e0b' }}>
            {currentCity.aqiStatus}
          </span>
        </div>
        <div className="metric-sub">
          Particulate matter (PM2.5/PM10) within regional safety standards.
        </div>
      </div>

      {/* Visibility */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>Visibility</span>
          <Eye size={16} color="#06b6d4" />
        </div>
        <div className="metric-value">
          {currentCity.visibility} km
        </div>
        <div className="metric-sub">
          Unobstructed atmospheric visibility across metropolitan area.
        </div>
      </div>

      {/* Pressure */}
      <div className="glass-card metric-card">
        <div className="metric-header">
          <span>Atmospheric Pressure</span>
          <Gauge size={16} color="#a855f7" />
        </div>
        <div className="metric-value">
          {currentCity.pressure} hPa
        </div>
        <div className="metric-sub">
          Stable barometric pressure profile across the district.
        </div>
      </div>

    </div>
  );
}
