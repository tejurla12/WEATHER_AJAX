import React, { useState } from 'react';
import { 
  Building, 
  Search, 
  SlidersHorizontal, 
  Droplets, 
  Wind, 
  MapPin, 
  ArrowUpDown,
  ConditionIcon
} from './WeatherIcons';

export default function AllCitiesExplorer({ 
  allCities, 
  currentCityName, 
  onSelectCity, 
  unit 
}) {
  const [search, setSearch] = useState('');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedCondition, setSelectedCondition] = useState('All');
  const [sortBy, setSortBy] = useState('default');

  const states = ['All', ...Array.from(new Set(allCities.map(c => c.state))).sort()];
  const conditions = ['All', 'Sunny', 'Rainy', 'Cloudy', 'Partly Cloudy'];

  const formatTemp = (celsius) => {
    if (unit === 'F') {
      return Math.round((celsius * 9/5) + 32);
    }
    return Math.round(celsius);
  };

  let filtered = allCities.filter(c => {
    const matchesSearch = 
      c.city.toLowerCase().includes(search.toLowerCase()) ||
      c.state.toLowerCase().includes(search.toLowerCase());

    const matchesState = selectedState === 'All' || c.state === selectedState;
    const matchesCondition = selectedCondition === 'All' || c.condition.toLowerCase().includes(selectedCondition.toLowerCase());

    return matchesSearch && matchesState && matchesCondition;
  });

  if (sortBy === 'temp-high') {
    filtered.sort((a, b) => b.temperature - a.temperature);
  } else if (sortBy === 'temp-low') {
    filtered.sort((a, b) => a.temperature - b.temperature);
  } else if (sortBy === 'humidity') {
    filtered.sort((a, b) => b.humidity - a.humidity);
  } else if (sortBy === 'wind') {
    filtered.sort((a, b) => b.windSpeed - a.windSpeed);
  }

  return (
    <div className="glass-card" style={{ padding: '28px' }}>
      
      {/* Section Header */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '20px' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: 'var(--text-main)' }}>
            National 20-City Meteorological Registry
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '2px' }}>
            Real-time conditions observed across India's primary meteorological observation stations
          </p>
        </div>

        <div style={{ fontSize: '12.5px', color: 'var(--text-muted)', fontWeight: 600 }}>
          Displaying {filtered.length} of {allCities.length} Stations
        </div>
      </div>

      {/* Filter and Sort Toolbar */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center', marginBottom: '22px' }}>
        
        {/* Search Input */}
        <div style={{ position: 'relative', flex: '1', minWidth: '220px' }}>
          <Search size={15} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            placeholder="Filter registry by city or state..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="weather-search-input"
            style={{ paddingLeft: '34px', fontSize: '13px', borderRadius: '10px', padding: '10px 14px 10px 34px' }}
          />
        </div>

        {/* State Filter */}
        <select 
          className="weather-select"
          value={selectedState}
          onChange={(e) => setSelectedState(e.target.value)}
          style={{ minWidth: '150px', fontSize: '13px', padding: '10px 14px', borderRadius: '10px' }}
        >
          {states.map(st => (
            <option key={st} value={st}>{st === 'All' ? 'All States' : st}</option>
          ))}
        </select>

        {/* Condition Filter */}
        <select 
          className="weather-select"
          value={selectedCondition}
          onChange={(e) => setSelectedCondition(e.target.value)}
          style={{ minWidth: '150px', fontSize: '13px', padding: '10px 14px', borderRadius: '10px' }}
        >
          {conditions.map(cd => (
            <option key={cd} value={cd}>{cd === 'All' ? 'All Conditions' : cd}</option>
          ))}
        </select>

        {/* Sort Dropdown */}
        <select 
          className="weather-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          style={{ minWidth: '150px', fontSize: '13px', padding: '10px 14px', borderRadius: '10px' }}
        >
          <option value="default">Default Order</option>
          <option value="temp-high">Temperature (High to Low)</option>
          <option value="temp-low">Temperature (Low to High)</option>
          <option value="humidity">Highest Humidity</option>
          <option value="wind">Highest Wind Speed</option>
        </select>
      </div>

      {/* Grid of Cities */}
      <div className="all-cities-grid">
        {filtered.map(item => {
          const isSelected = item.city.toLowerCase() === currentCityName?.toLowerCase();
          
          return (
            <div 
              key={item.city} 
              className={`city-tile ${isSelected ? 'selected' : ''}`}
              onClick={() => onSelectCity(item.city)}
            >
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-main)' }}>
                    {item.city}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '3px', marginTop: '2px' }}>
                    <MapPin size={11} />
                    <span>{item.state}</span>
                  </div>
                </div>

                <ConditionIcon condition={item.condition} size={28} />
              </div>

              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginTop: '6px' }}>
                <span style={{ fontSize: '28px', fontWeight: 800, color: 'var(--text-main)', fontFamily: 'var(--font-heading)' }}>
                  {formatTemp(item.temperature)}°{unit}
                </span>

                <span style={{ fontSize: '12.5px', fontWeight: 600, color: 'var(--text-muted)' }}>
                  {item.condition}
                </span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11.5px', color: 'var(--text-dim)', borderTop: '1px solid var(--border-subtle)', paddingTop: '10px' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Droplets size={12} color="#38bdf8" /> Humidity: {item.humidity}%
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Wind size={12} color="#818cf8" /> Wind: {item.windSpeed} km/h
                </span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
