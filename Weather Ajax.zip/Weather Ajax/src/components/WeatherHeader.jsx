import React, { useState, useEffect } from 'react';
import { CloudLightning, Sun, Moon, Clock } from './WeatherIcons';

export default function WeatherHeader({ unit, setUnit, theme, toggleTheme }) {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false 
      }) + ' IST');
    };
    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="site-header">
      <div className="header-brand">
        <div className="brand-icon">
          <CloudLightning size={22} />
        </div>
        <div className="brand-info">
          <h1>SKY<span style={{ color: '#38bdf8' }}>PULSE</span></h1>
          <p>National Meteorological Network</p>
        </div>
      </div>

      <div className="header-actions">
        {/* Live Radar Pill */}
        <div className="chip-btn" style={{ cursor: 'default', background: 'rgba(16, 185, 129, 0.1)', borderColor: 'rgba(16, 185, 129, 0.25)', color: '#10b981' }}>
          <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 6px #10b981' }}></span>
          <span style={{ fontSize: '11.5px', fontWeight: 600 }}>Doppler Radar Active</span>
        </div>

        {/* Live Clock */}
        <div className="chip-btn" style={{ fontFamily: 'monospace', fontSize: '12px' }}>
          <Clock size={13} color="var(--text-muted)" />
          <span>{timeStr}</span>
        </div>

        {/* Unit Toggle */}
        <div style={{ display: 'flex', background: 'var(--bg-surface-elevated)', borderRadius: '10px', padding: '3px', border: '1px solid var(--border-subtle)' }}>
          <button 
            onClick={() => setUnit('C')}
            style={{
              padding: '4px 10px',
              borderRadius: '8px',
              border: 'none',
              fontSize: '12px',
              fontWeight: 700,
              cursor: 'pointer',
              background: unit === 'C' ? '#0284c7' : 'transparent',
              color: unit === 'C' ? '#fff' : 'var(--text-muted)',
              transition: 'all 0.15s ease'
            }}
          >
            °C
          </button>
          <button 
            onClick={() => setUnit('F')}
            style={{
              padding: '4px 10px',
              borderRadius: '8px',
              border: 'none',
              fontSize: '12px',
              fontWeight: 700,
              cursor: 'pointer',
              background: unit === 'F' ? '#0284c7' : 'transparent',
              color: unit === 'F' ? '#fff' : 'var(--text-muted)',
              transition: 'all 0.15s ease'
            }}
          >
            °F
          </button>
        </div>

        {/* Theme Toggle */}
        <button 
          onClick={toggleTheme}
          className="chip-btn"
          title="Toggle Light/Dark Theme"
        >
          {theme === 'dark' ? <Sun size={15} color="#fbbf24" /> : <Moon size={15} color="#0284c7" />}
        </button>
      </div>
    </header>
  );
}
