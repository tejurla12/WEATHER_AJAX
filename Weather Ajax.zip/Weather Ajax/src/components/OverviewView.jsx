import React from 'react';
import { 
  Building2, 
  Users, 
  ShieldCheck, 
  AlertTriangle, 
  TrendingUp, 
  CloudSun, 
  Activity, 
  ArrowRight,
  Droplets,
  Wind,
  Thermometer
} from 'lucide-react';
import StatCard from './StatCard';

export default function OverviewView({ data, branches, onNavigateTab }) {
  const metrics = data?.metrics || {
    totalWorkforce: 17540,
    totalHubs: 20,
    optimalHubs: 16,
    weatherAdvisories: 4,
    avgFacilityHealth: '97%',
    attendanceRate: '96.4%',
    activeProjects: 128,
    totalBudget: '₹188.5M'
  };

  const weatherHighlights = branches?.slice(0, 6) || [];
  const activities = data?.recentActivities || [];

  return (
    <div>
      {/* Top Banner Alert for Weather / Operations if any advisory */}
      {metrics.weatherAdvisories > 0 && (
        <div style={{
          background: 'linear-gradient(90deg, rgba(245, 158, 11, 0.12), rgba(245, 158, 11, 0.04))',
          border: '1px solid rgba(245, 158, 11, 0.3)',
          borderRadius: '12px',
          padding: '14px 20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '24px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <AlertTriangle size={20} color="#f59e0b" />
            <div>
              <span style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '13.5px' }}>
                Regional Telemetry Notice:
              </span>
              <span style={{ color: 'var(--text-secondary)', fontSize: '13px', marginLeft: '6px' }}>
                {metrics.weatherAdvisories} coastal and high-temperature facilities are actively operating under Climate Contingency Level 1.
              </span>
            </div>
          </div>
          <button 
            className="btn-secondary" 
            style={{ fontSize: '12px', padding: '6px 12px' }}
            onClick={() => onNavigateTab('branches')}
          >
            Review Facilities
          </button>
        </div>
      )}

      {/* KPI Stats Grid */}
      <div className="stat-grid">
        <StatCard 
          title="Total Enterprise Headcount"
          value={metrics.totalWorkforce.toLocaleString()}
          subtitle="Across 20 regional centers"
          trend="+3.8% this quarter"
          trendUp={true}
          icon={Users}
          accent="primary"
        />
        <StatCard 
          title="Regional Operations Hubs"
          value={`${metrics.totalHubs} Hubs`}
          subtitle={`${metrics.optimalHubs} operating at peak status`}
          trend="100% operational"
          trendUp={true}
          icon={Building2}
          accent="emerald"
        />
        <StatCard 
          title="Infrastructure Resilience"
          value={metrics.avgFacilityHealth}
          subtitle="Audit compliance rating"
          trend="+1.2% reliability"
          trendUp={true}
          icon={ShieldCheck}
          accent="cyan"
        />
        <StatCard 
          title="Daily Attendance Rate"
          value={metrics.attendanceRate}
          subtitle="Hybrid & Onsite aggregate"
          trend="Target: 95.0%"
          trendUp={true}
          icon={Activity}
          accent="purple"
        />
      </div>

      {/* Middle Grid: Operational Hubs Telemetry & Attendance Chart */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: '24px', marginBottom: '28px' }}>
        
        {/* Live Facility Telemetry Snapshot */}
        <div className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
                Key Regional Hubs & Atmospheric Monitoring
              </h3>
              <p style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginTop: '2px' }}>
                Live environmental parameters affecting onsite teams
              </p>
            </div>
            <button 
              className="btn-secondary" 
              style={{ fontSize: '12px', padding: '6px 12px' }}
              onClick={() => onNavigateTab('branches')}
            >
              <span>View All 20 Hubs</span>
              <ArrowRight size={13} />
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '14px' }}>
            {weatherHighlights.map(hub => {
              const isRain = hub.environment?.condition?.toLowerCase().includes('rain');
              const isHighHeat = hub.environment?.temperature >= 35;

              return (
                <div 
                  key={hub.id} 
                  style={{
                    padding: '14px',
                    borderRadius: '10px',
                    background: 'var(--bg-surface-elevated)',
                    border: '1px solid var(--border-subtle)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '14px', color: 'var(--text-primary)' }}>
                        {hub.city}
                      </div>
                      <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                        {hub.state}
                      </div>
                    </div>
                    <span className={`status-badge ${hub.status === 'Optimal' ? 'status-optimal' : 'status-warning'}`}>
                      {hub.status === 'Optimal' ? 'Optimal' : 'Advisory'}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '4px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '18px', fontWeight: 800 }}>
                      <Thermometer size={16} color={isHighHeat ? '#f43f5e' : '#3b82f6'} />
                      <span>{hub.environment?.temperature}°C</span>
                    </div>
                    <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                      {hub.environment?.condition}
                    </span>
                  </div>

                  <div style={{ display: 'flex', gap: '12px', fontSize: '11px', color: 'var(--text-muted)', borderTop: '1px solid var(--border-subtle)', paddingTop: '6px' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '3px' }}>
                      <Droplets size={11} /> {hub.environment?.humidity}%
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '3px' }}>
                      <Wind size={11} /> {hub.environment?.windSpeed} km/h
                    </span>
                    <span style={{ marginLeft: 'auto', fontWeight: 600, color: 'var(--text-secondary)' }}>
                      {hub.headcount} staff
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weekly Attendance & Shift Analytics */}
        <div className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
                Weekly Workforce Presence & Attendance
              </h3>
              <p style={{ fontSize: '12.5px', color: 'var(--text-muted)', marginTop: '2px' }}>
                Onsite vs. Approved Remote Distribution (Current Week)
              </p>
            </div>
            <div style={{ display: 'flex', gap: '12px', fontSize: '11.5px' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '2px', background: '#3b82f6' }}></span>
                <span>Onsite Facility</span>
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ width: '8px', height: '8px', borderRadius: '2px', background: '#06b6d4' }}></span>
                <span>Remote / Field</span>
              </span>
            </div>
          </div>

          {/* SVG Attendance Chart */}
          <div style={{ height: '220px', display: 'flex', alignItems: 'flex-end', gap: '24px', padding: '10px 10px 0' }}>
            {[
              { day: 'Mon', onsite: 94.2, remote: 4.8 },
              { day: 'Tue', onsite: 96.5, remote: 2.8 },
              { day: 'Wed', onsite: 97.1, remote: 2.2 },
              { day: 'Thu', onsite: 95.8, remote: 3.1 },
              { day: 'Fri', onsite: 92.4, remote: 6.2 }
            ].map(item => (
              <div key={item.day} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-muted)' }}>
                  {item.onsite}%
                </div>
                <div style={{ width: '100%', height: '150px', display: 'flex', flexDirection: 'column-reverse', borderRadius: '6px', overflow: 'hidden', background: 'var(--bg-surface-elevated)' }}>
                  <div style={{ height: `${(item.onsite / 100) * 150}px`, background: 'linear-gradient(180deg, #3b82f6, #1d4ed8)', width: '100%' }}></div>
                  <div style={{ height: `${(item.remote / 100) * 150}px`, background: '#06b6d4', width: '100%' }}></div>
                </div>
                <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)' }}>
                  {item.day}
                </span>
              </div>
            ))}
          </div>

          <div style={{ marginTop: '20px', padding: '12px 16px', background: 'var(--bg-surface-elevated)', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '12.5px' }}>
            <span style={{ color: 'var(--text-secondary)' }}>Average Daily Facility Occupancy:</span>
            <span style={{ fontWeight: 700, color: 'var(--accent-emerald)' }}>95.2% (Compliance Threshold Met)</span>
          </div>
        </div>
      </div>

      {/* Bottom Section: Enterprise Activity Feed & Department Allocations */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', gap: '24px' }}>
        
        {/* Activity Feed */}
        <div className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Operational Audit & Activity Log
            </h3>
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Real-time event stream</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {activities.map(act => (
              <div 
                key={act.id} 
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '12px',
                  paddingBottom: '12px',
                  borderBottom: '1px solid var(--border-subtle)'
                }}
              >
                <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#3b82f6', marginTop: '6px' }}></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)' }}>
                    {act.action}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '2px' }}>
                    {act.target}
                  </div>
                </div>
                <span style={{ fontSize: '11px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
                  {act.timestamp}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Division Resource Summary */}
        <div className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-primary)' }}>
              Executive Division Allocations
            </h3>
            <button 
              className="btn-secondary" 
              style={{ fontSize: '12px', padding: '5px 10px' }}
              onClick={() => onNavigateTab('departments')}
            >
              Details
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {[
              { name: "Engineering & Innovation", head: "Rajeshwar Rao", count: 6850, pct: 39 },
              { name: "Operations & Facilities", head: "Ananya Sundaram", count: 3420, pct: 20 },
              { name: "Logistics & Supply Chain", head: "Srinivas Naidu", count: 2180, pct: 13 },
              { name: "Finance & Corporate Audit", head: "Pooja Deshmukh", count: 1240, pct: 9 }
            ].map(item => (
              <div key={item.name}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', marginBottom: '6px' }}>
                  <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{item.name}</span>
                  <span style={{ color: 'var(--text-muted)' }}>{item.count.toLocaleString()} personnel ({item.pct}%)</span>
                </div>
                <div style={{ width: '100%', height: '6px', background: 'var(--bg-surface-elevated)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ width: `${item.pct * 2}%`, height: '100%', background: '#3b82f6', borderRadius: '3px' }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
