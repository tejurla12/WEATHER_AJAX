import React, { useState } from 'react';
import { 
  MapPin, 
  Search, 
  Droplets, 
  Wind, 
  Thermometer, 
  Sunrise, 
  Sunset,
  ArrowUp,
  ArrowDown,
  ConditionIcon
} from './WeatherIcons';

export default function HeroWeatherCard({ 
  currentCity, 
  allCities, 
  onSelectCity, 
  unit 
}) {
  const [selectedDropdownCity, setSelectedDropdownCity] = useState(currentCity?.city || '');
  const [searchQuery, setSearchQuery] = useState('');

  // Temperature converter helper
  const formatTemp = (celsius) => {
    if (unit === 'F') {
      return Math.round((celsius * 9/5) + 32);
    }
    return Math.round(celsius);
  };

  const handleDropdownChange = (e) => {
    const cityName = e.target.value;
    setSelectedDropdownCity(cityName);
    if (cityName) {
      onSelectCity(cityName);
    }
  };

  const handleSearchClick = () => {
    if (selectedDropdownCity) {
      onSelectCity(selectedDropdownCity);
    } else if (searchQuery.trim()) {
      const match = allCities.find(c => 
        c.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.state.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (match) {
        onSelectCity(match.city);
        setSelectedDropdownCity(match.city);
      } else {
        alert("City not found in national observation network. Please choose from the 20 available hubs.");
      }
    } else {
      alert("Please select a city!");
    }
  };

  const handleInputSubmit = (e) => {
    e.preventDefault();
    handleSearchClick();
  };

  if (!currentCity) return null;

  const conditionClass = currentCity.condition.toLowerCase().includes('rain') 
    ? 'hero-condition-rainy' 
    : currentCity.condition.toLowerCase().includes('partly')
      ? 'hero-condition-partly-cloudy'
      : currentCity.condition.toLowerCase().includes('cloud')
        ? 'hero-condition-cloudy'
        : 'hero-condition-sunny';

  return (
    <div className={`glass-card hero-weather-display ${conditionClass}`}>
      
      {/* Top Search & Dropdown Control Bar */}
      <div style={{ borderBottom: '1px solid var(--border-subtle)', paddingBottom: '20px', marginBottom: '24px' }}>
        <form onSubmit={handleInputSubmit} className="search-container" style={{ margin: 0 }}>
          
          {/* Native Styled Dropdown Selector matching original project */}
          <select 
            id="city"
            className="weather-select"
            value={currentCity.city}
            onChange={handleDropdownChange}
          >
            <option value="">Select Your City</option>
            {allCities.map(item => (
              <option key={item.city} value={item.city}>
                {item.city} ({item.state})
              </option>
            ))}
          </select>

          {/* Search Input for fast typing/autocomplete */}
          <div className="search-input-wrapper">
            <Search size={16} style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
            <input 
              type="text"
              placeholder="Or type city name (e.g. Mumbai, Bengaluru, Hyderabad)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="weather-search-input"
            />
          </div>

          {/* Search Button matching original project */}
          <button type="button" onClick={handleSearchClick} className="btn-search">
            <Search size={16} />
            <span>Search Weather</span>
          </button>
        </form>
      </div>

      {/* Main City Weather Overview */}
      <div className="hero-layout">
        <div>
          {/* Location details */}
          <div className="hero-city-title">
            <span>{currentCity.city}</span>
            <span style={{ fontSize: '20px', color: 'var(--accent-cyan)' }}>•</span>
            <span style={{ fontSize: '22px', fontWeight: 600, color: 'var(--text-muted)' }}>{currentCity.state}</span>
          </div>

          <div className="hero-state-subtitle" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <MapPin size={15} color="#0284c7" />
            <span>India National Weather Observation Network</span>
            <span>•</span>
            <span>Updated Just Now</span>
          </div>

          {/* Giant Temperature & Condition */}
          <div className="hero-temp-block">
            <div className="hero-temperature">
              {formatTemp(currentCity.temperature)}°{unit}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <div className="hero-condition-badge">
                <ConditionIcon condition={currentCity.condition} size={18} />
                <span>{currentCity.condition}</span>
              </div>

              <div style={{ fontSize: '13px', color: 'var(--text-muted)', fontWeight: 500 }}>
                Feels like {formatTemp(currentCity.feelsLike)}°{unit}
              </div>
            </div>
          </div>

          {/* Summary Badges: High/Low, Sunrise, Sunset */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', marginTop: '20px', fontSize: '13px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-main)', background: 'var(--bg-surface-elevated)', padding: '5px 12px', borderRadius: '8px' }}>
              <ArrowUp size={14} color="#f43f5e" />
              <span>High: {formatTemp(currentCity.temperature + 2)}°{unit}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-main)', background: 'var(--bg-surface-elevated)', padding: '5px 12px', borderRadius: '8px' }}>
              <ArrowDown size={14} color="#38bdf8" />
              <span>Low: {formatTemp(Math.round(currentCity.temperature * 0.72))}°{unit}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)' }}>
              <Sunrise size={15} color="#fbbf24" />
              <span>Sunrise: {currentCity.sunrise}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)' }}>
              <Sunset size={15} color="#f97316" />
              <span>Sunset: {currentCity.sunset}</span>
            </div>
          </div>
        </div>

        {/* Large Visual Condition Avatar */}
        <div style={{
          width: '160px',
          height: '160px',
          borderRadius: '30px',
          background: 'var(--bg-surface-elevated)',
          border: '1px solid var(--border-medium)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '12px',
          boxShadow: '0 12px 30px rgba(0, 0, 0, 0.15)'
        }}>
          <ConditionIcon condition={currentCity.condition} size={70} />
          <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-main)', textTransform: 'capitalize' }}>
            {currentCity.condition}
          </span>
        </div>
      </div>

    </div>
  );
}
