import React, { useState } from 'react';
import { AlertTriangle, ChevronRight, X } from './WeatherIcons';

export default function AlertsBanner({ alerts, onSelectCity }) {
  const [dismissed, setDismissed] = useState(false);

  if (!alerts || alerts.length === 0 || dismissed) return null;

  return (
    <div style={{
      background: 'linear-gradient(90deg, rgba(245, 158, 11, 0.16) 0%, rgba(245, 158, 11, 0.05) 100%)',
      border: '1px solid rgba(245, 158, 11, 0.35)',
      borderRadius: '16px',
      padding: '14px 20px',
      marginBottom: '24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '14px'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          width: '32px',
          height: '32px',
          borderRadius: '8px',
          background: 'rgba(245, 158, 11, 0.2)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#f59e0b'
        }}>
          <AlertTriangle size={18} />
        </div>

        <div>
          <span style={{ fontSize: '13px', fontWeight: 700, color: '#f59e0b', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            National Weather Alert ({alerts.length} Stations Active):
          </span>
          <span style={{ fontSize: '13px', color: 'var(--text-main)', marginLeft: '8px' }}>
            {alerts[0].city} ({alerts[0].state}): {alerts[0].alert}
          </span>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <button
          onClick={() => onSelectCity(alerts[0].city)}
          className="chip-btn"
          style={{ fontSize: '12px', padding: '5px 10px', background: 'rgba(245, 158, 11, 0.2)', borderColor: 'rgba(245, 158, 11, 0.4)', color: '#f59e0b' }}
        >
          <span>Inspect {alerts[0].city}</span>
          <ChevronRight size={13} />
        </button>

        <button 
          onClick={() => setDismissed(true)}
          style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: '4px' }}
          title="Dismiss Banner"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
