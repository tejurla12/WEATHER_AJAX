import React from 'react';
import { CalendarDays, Droplets, ConditionIcon } from './WeatherIcons';

export default function DailyForecast({ daily, unit }) {
  if (!daily || daily.length === 0) return null;

  const formatTemp = (celsius) => {
    if (unit === 'F') {
      return Math.round((celsius * 9/5) + 32);
    }
    return Math.round(celsius);
  };

  return (
    <div className="glass-card" style={{ padding: '24px', marginBottom: '28px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px', fontWeight: 700, color: 'var(--text-main)', marginBottom: '18px' }}>
        <CalendarDays size={17} color="#0284c7" />
        <span>7-Day Extended Meteorological Outlook</span>
      </div>

      <div className="daily-list">
        {daily.map((item, idx) => (
          <div key={idx} className="daily-row">
            
            {/* Day and Date */}
            <div style={{ width: '110px' }}>
              <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-main)' }}>
                {item.day}
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                {item.date}
              </div>
            </div>

            {/* Condition Icon and Name */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: '150px' }}>
              <ConditionIcon condition={item.condition} size={22} />
              <span style={{ fontSize: '13px', color: 'var(--text-main)', fontWeight: 500 }}>
                {item.condition}
              </span>
            </div>

            {/* Rain chance */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', minWidth: '70px', color: item.rainChance > 40 ? '#38bdf8' : 'var(--text-muted)' }}>
              <Droplets size={13} />
              <span>{item.rainChance}%</span>
            </div>

            {/* Temperature range bar */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: '180px' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-muted)', width: '34px', textAlign: 'right' }}>
                {formatTemp(item.tempLow)}°
              </span>

              <div style={{ flex: 1, height: '6px', background: 'var(--bg-surface)', borderRadius: '3px', overflow: 'hidden' }}>
                <div style={{
                  width: `${Math.min(100, Math.max(20, (item.tempHigh - item.tempLow) * 10))}%`,
                  height: '100%',
                  background: 'linear-gradient(90deg, #38bdf8, #fbbf24)',
                  borderRadius: '3px',
                  marginLeft: 'auto'
                }}></div>
              </div>

              <span style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-main)', width: '34px' }}>
                {formatTemp(item.tempHigh)}°
              </span>
            </div>

          </div>
        ))}
      </div>
    </div>
  );
}
