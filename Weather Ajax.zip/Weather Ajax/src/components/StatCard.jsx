import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

export default function StatCard({ title, value, subtitle, trend, trendUp, icon: Icon, accent = 'primary' }) {
  const accentColors = {
    primary: {
      bg: 'rgba(59, 130, 246, 0.12)',
      text: '#3b82f6',
      border: 'rgba(59, 130, 246, 0.2)'
    },
    emerald: {
      bg: 'rgba(16, 185, 129, 0.12)',
      text: '#10b981',
      border: 'rgba(16, 185, 129, 0.2)'
    },
    amber: {
      bg: 'rgba(245, 158, 11, 0.12)',
      text: '#f59e0b',
      border: 'rgba(245, 158, 11, 0.2)'
    },
    cyan: {
      bg: 'rgba(6, 182, 212, 0.12)',
      text: '#06b6d4',
      border: 'rgba(6, 182, 212, 0.2)'
    },
    purple: {
      bg: 'rgba(139, 92, 246, 0.12)',
      text: '#8b5cf6',
      border: 'rgba(139, 92, 246, 0.2)'
    }
  };

  const currentAccent = accentColors[accent] || accentColors.primary;

  return (
    <div className="card" style={{ padding: '22px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '14px' }}>
        <div>
          <span style={{ fontSize: '13px', color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
            {title}
          </span>
          <div style={{ fontSize: '28px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '4px', letterSpacing: '-0.02em' }}>
            {value}
          </div>
        </div>

        {Icon && (
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            background: currentAccent.bg,
            border: `1px solid ${currentAccent.border}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: currentAccent.text
          }}>
            <Icon size={20} />
          </div>
        )}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '12.5px', marginTop: '6px' }}>
        <span style={{ color: 'var(--text-secondary)' }}>{subtitle}</span>
        {trend && (
          <span style={{
            display: 'flex',
            alignItems: 'center',
            gap: '3px',
            fontWeight: 600,
            color: trendUp ? 'var(--accent-emerald)' : 'var(--accent-rose)'
          }}>
            {trendUp ? <ArrowUpRight size={15} /> : <ArrowDownRight size={15} />}
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}
