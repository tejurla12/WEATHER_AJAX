import React from 'react';
import { Layers, Briefcase, DollarSign, Target, CheckCircle2, TrendingUp, Users } from 'lucide-react';

export default function DepartmentsView({ departments }) {
  const initiatives = {
    'DEP-1': ['GenAI Operational Assistants', 'Cloud Infrastructure Scalability', 'Next-Gen Mobile Platform'],
    'DEP-2': ['Zero-Emission Corporate Transit', 'Smart HVAC IoT Optimization', 'Renewable Energy Integration'],
    'DEP-3': ['Automated Financial Reconciliation', 'Cross-Border Tax Compliance', 'Corporate Treasury Modernization'],
    'DEP-4': ['Maritime Port Telemetry Gateway', 'Cold-Chain Logistics Monitoring', 'Last-Mile Delivery Routing'],
    'DEP-5': ['Unified Enterprise Design System', 'Customer Journey Telemetry', 'B2B Client Portal Redesign'],
    'DEP-6': ['Data Governance & Privacy Framework', 'Statutory Regional Audit Prep', 'ESG Regulatory Reporting']
  };

  return (
    <div>
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-primary)' }}>
          Enterprise Divisions & Operational Portfolios
        </h2>
        <p style={{ fontSize: '13px', color: 'var(--text-muted)', marginTop: '3px' }}>
          Strategic alignment, executive leadership, headcount, and capital expenditure allocation
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '22px' }}>
        {departments.map(dept => {
          const list = initiatives[dept.id] || ['Core Operations', 'Digital Transformation'];
          return (
            <div key={dept.id} className="card" style={{ padding: '22px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--primary)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                    {dept.id}
                  </div>
                  <h3 style={{ fontSize: '17px', fontWeight: 700, color: 'var(--text-primary)', marginTop: '2px' }}>
                    {dept.name}
                  </h3>
                </div>
                <span className="status-badge status-optimal">
                  {dept.health} Health
                </span>
              </div>

              <div style={{ background: 'var(--bg-surface-elevated)', borderRadius: '10px', padding: '14px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', textAlign: 'center' }}>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Workforce</div>
                  <div style={{ fontSize: '15px', fontWeight: 800, color: 'var(--text-primary)', marginTop: '2px' }}>
                    {dept.headcount.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Projects</div>
                  <div style={{ fontSize: '15px', fontWeight: 800, color: '#3b82f6', marginTop: '2px' }}>
                    {dept.activeProjects} Active
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Annual Budget</div>
                  <div style={{ fontSize: '15px', fontWeight: 800, color: 'var(--accent-emerald)', marginTop: '2px' }}>
                    {dept.budget}
                  </div>
                </div>
              </div>

              <div>
                <div style={{ fontSize: '12.5px', color: 'var(--text-secondary)' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Executive Division Lead: </span>
                  <strong style={{ color: 'var(--text-primary)' }}>{dept.head}</strong>
                </div>
              </div>

              <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '14px', marginTop: 'auto' }}>
                <div style={{ fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)', letterSpacing: '0.04em', marginBottom: '8px' }}>
                  Active Strategic Initiatives
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {list.map((item, idx) => (
                    <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12.5px', color: 'var(--text-secondary)' }}>
                      <CheckCircle2 size={13} color="#10b981" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
