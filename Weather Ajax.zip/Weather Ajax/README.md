# Skypulse Weather — National Climate & Meteorological Intelligence Network

A high-performance full-stack meteorological platform delivering live atmospheric observations, 24-hour timelines, 7-day extended forecasts, and environmental metrics across 20 key observation centers in India.

---

## Overview

Skypulse Weather provides real-time meteorological observations engineered with dynamic condition styling, interactive parameter filtering, and responsive atmospheric telemetry.

### Core Features

- **Primary Observation Center**:
  - Live temperature observation with Celsius (°C) and Fahrenheit (°F) conversion.
  - Interactive city dropdown (`<select id="city">`) and instant search input covering all 20 national hubs.
  - Feels Like, Today's High & Low temperatures, Sunrise and Sunset schedules.
- **Detailed Atmospheric Metrics (6 Key Gauges)**:
  - Relative Humidity (%) and Dew Point comfort index.
  - Wind Speed (km/h & mph) with vector direction (e.g. ENE, WSW) and Beaufort scale rating.
  - Ultraviolet (UV) radiation index with midday exposure guidance.
  - Air Quality Index (AQI) with categorical safety analysis.
  - Horizontal Atmospheric Visibility (km).
  - Barometric Pressure (hPa).
- **24-Hour Atmospheric Timeline**:
  - Horizontal hourly trajectory with time-step temperatures and Probability of Precipitation (PoP %).
- **7-Day Extended Outlook**:
  - Day-by-day temperature gradients, forecast conditions, and rain probability bars.
- **National 20-City Registry Explorer**:
  - Full observation grid covering Hyderabad, Chennai, Bengaluru, Mumbai, New Delhi, Kolkata, Vijayawada, Visakhapatnam, Guntur, Macherla, Pondicherry, Coimbatore, Kochi, Thiruvananthapuram, Pune, Ahmedabad, Jaipur, Lucknow, Bhopal, and Bhubaneswar.
  - Multi-attribute filtering by State, Condition, and sorting by Temperature, Humidity, or Wind Speed.
- **Active Weather & Precipitation Advisories**:
  - Automatic banner alerts for precipitation, monsoon winds, and thermal alerts.
- **Adaptive UI Architecture**:
  - Dynamic condition-based atmospheric gradients (Sunny, Rainy, Cloudy, Partly Cloudy).
  - Day & Night Theme toggling.
  - Responsive design optimized for desktop, tablet, and mobile displays.

---

## Technology Stack

- **Frontend**: React 19, Modern CSS3 Glassmorphism System, Lucide Icons, Outfit & Plus Jakarta Sans typography.
- **Backend**: Node.js & Express RESTful API with automated meteorological calculations.
- **Data Engine**: Comprehensive observations engine covering 20 Indian cities and regional atmospheric indices.

---

## Quick Start

### 1. Clone & Install
```bash
git clone https://github.com/your-username/skypulse-weather.git
cd skypulse-weather
npm install
```

### 2. Build Client Assets
```bash
npm run build
```

### 3. Launch Server
```bash
npm start
```

### 4. Open in Browser
Open `http://localhost:4000` in your web browser.

---

## API Documentation

| Endpoint | Method | Description |
|---|---|---|
| `/api/weather` | `GET` | Retrieve observations for all 20 cities with optional search and state filters |
| `/api/weather/:city` | `GET` | Detailed current observations, 24-hr hourly and 7-day extended forecasts |
| `/api/summary` | `GET` | National extremes (hottest, coolest, highest humidity, windiest stations) |
| `/api/alerts` | `GET` | Active regional weather alerts and advisories |
| `/api/cities` | `GET` | Lightweight city and state lookup list |
